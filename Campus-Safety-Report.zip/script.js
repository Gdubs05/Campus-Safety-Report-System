
function toggleTextBox() {
  var reportSelect = document.getElementById("report");
  var otherTextBox = document.getElementById("other-textbox");

  if (reportSelect.value === "other") {
    otherTextBox.style.display = "block";
    otherTextBox.className = "small-textbox"; 
  } 
  else {
    otherTextBox.style.display = "none";
    otherTextBox.className = ""; 
  }
}

function showDorms(){
  var location = document.getElementById("location");
  var dorms = document.getElementById("dormsList");
  var listOfDorms = document.getElementById("listOfDorms");

  if (location.value === "Dorms"){
    dorms.style.display = "block";
    listOfDorms.style.display = "block";
  }

  else {
    dorms.style.display ="none";
    listOfDorms.style.display = "none";
  }
}

function updateCharacterCount() {
    var complaintTextarea = document.getElementsByName("complaint")[0];
    var counterSpan = document.getElementById("character-count");
    var remainingChars = 250 - complaintTextarea.value.length;
    counterSpan.textContent = "Characters remaining: " + remainingChars;
  }

function validateForm() {
  var reportSelect = document.getElementById("report");
  var complaintTextarea = document.getElementsByName("complaint")[0];
  var studentIDInput = document.getElementsByName("studentID")[0];
  var passwordInput = document.getElementsByName("secret")[0];
  var otherDetailsInput = document.getElementById("other-details");

  if (reportSelect.value === "other" && otherDetailsInput.value === "") {
    alert("Please specify other details.");
    return false;
  }

  if (complaintTextarea.value === "") {
    alert("Please enter your complaint.");
    return false;
  }

  if (complaintTextarea.value.length > 250) {
    alert("Complaint should not exceed 250 characters.");
    return false;
  }

  if (studentIDInput.value === "" || passwordInput.value === "") {
    alert("Please enter your student ID and password.");
    return false;
  }

  return true;
}

