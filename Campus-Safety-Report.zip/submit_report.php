<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Gather form data
    $reportType = $_POST['report'];
    $otherDetails = isset($_POST['other-details']) ? $_POST['other-details'] : '';
    $location = $_POST['location'];
    $dorm = isset($_POST['selectedDorm']) ? $_POST['selectedDorm'] : '';
    $complaint = $_POST['complaint'];
    $studentID = $_POST['studentID'];
    $password = $_POST['secret'];

    // Compose email message
    $to = "gwesleyking@gmail.com"; 
    $subject = "Campus Safety Report";
    $message = "Report Type: $reportType\n";
    $message .= "Other Details: $otherDetails\n";
    $message .= "Location: $location\n";
    $message .= "Dorm: $dorm\n";
    $message .= "Complaint: $complaint\n";
    $message .= "Student ID: $studentID\n";

    // Send email
    if (mail($to, $subject, $message)) {
        echo '<div style="background-color: #2e4b6b">';
        echo '<p style="font-size: 20px">Report submitted successfully. Thank you!</p>';
        echo '</div>';
    } else {
        echo "Error submitting report. Please try again later.";
    }
}
?>
